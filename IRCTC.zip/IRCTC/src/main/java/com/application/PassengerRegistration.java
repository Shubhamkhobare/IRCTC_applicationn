package com.application;

import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PassengerRegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;

	 
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/irctc";

    
    static final String USER = "root";
    static final String PASS = "1947Srksrk";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        

    	String fullname = request.getParameter("fullname");
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String phoneNumber = request.getParameter("phoneNumber");
        String password = request.getParameter("password");
        
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            
            Class.forName(JDBC_DRIVER);

            
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            
            String sql = "INSERT INTO passenger (full_name,username,email,phone_number, password ) VALUES (?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, fullname);
            stmt.setString(2, username);
            stmt.setString(3, email);
            stmt.setString(4, phoneNumber);
            stmt.setString(5, password);

           
            stmt.executeUpdate();

          
            response.sendRedirect("PassengerDashboard.jsp");
        } catch (ClassNotFoundException | SQLException e) {
           
            e.printStackTrace();
            
            response.sendRedirect("start.jsp");
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}
