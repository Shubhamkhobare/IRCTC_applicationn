package com.application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class AdminLogin extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

      
        String email = request.getParameter("email");
        String password = request.getParameter("password");

     
        String jdbcURL = "jdbc:mysql://localhost:3306/irctc"; 
        String dbUser = "root"; 
        String dbPassword = "1947Srksrk"; 

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            String sql = "SELECT * FROM admin WHERE email = ? AND password = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, email);
            statement.setString(2, password);

         
            ResultSet result = statement.executeQuery();

        
            if (result.next()) {
           
                response.sendRedirect("AdminDashboard.jsp"); 
            } else {
                
                response.sendRedirect("Start.jsp"); 
            }

            // Clean up resources
            result.close();
            statement.close();
            connection.close();

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            throw new ServletException("Database connection failed", e);
        }
    }
}
