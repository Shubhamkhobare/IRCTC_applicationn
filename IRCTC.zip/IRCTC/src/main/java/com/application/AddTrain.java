package com.application;

import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AddTrain extends HttpServlet {
	private static final long serialVersionUID = 1L;


    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/irctc";


    static final String USER = "root";
    static final String PASS = "1947Srksrk";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        

        String trainNumber = request.getParameter("trainNo");
        String trainName = request.getParameter("trainName");
        String source = request.getParameter("source");
        String destination = request.getParameter("destination");
        String date = request.getParameter("date");
        
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {

            Class.forName(JDBC_DRIVER);


            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            String sql = "INSERT INTO trainn (train_no,train_name, source, destination,date ) VALUES (?, ?, ?, ?, ?)";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, trainNumber);
            stmt.setString(2, trainName);
            stmt.setString(3, source);
            stmt.setString(4, destination);
            stmt.setString(5, date);

  
            stmt.executeUpdate();

  
            response.sendRedirect("AdminDashboard.jsp");
        } catch (ClassNotFoundException | SQLException e) {
   
            e.printStackTrace();
 
            response.sendRedirect("start.jsp");
        } finally {

            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}