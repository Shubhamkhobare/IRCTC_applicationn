package com.application;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.application.TrainEntity;

public class traindaoo {

	private String jdbcURL = "jdbc:mysql://localhost:3306/irctc?useSSL=false";
	private String jdbcUsername = "root";
	private String jdbcPassword = "1947Srksrk";
	
	private static final String SELECT_ALL_USERS = "select * from trainn";
	public traindaoo() {
	}
	
	protected Connection getConnection() throws ClassNotFoundException {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		} catch (SQLException e) {
		
			e.printStackTrace();
		} 
		return connection;
	}
	
	public List<TrainEntity> selectAllUsers() throws Exception {

		
		List<TrainEntity> train = new ArrayList<>();
		
		try (Connection connection = getConnection();

				
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_USERS);) {
			System.out.println(preparedStatement);
			
			ResultSet rs = preparedStatement.executeQuery();

			
			while (rs.next()) {
				int train_no = rs.getInt("train_no");
				String train_name = rs.getString("train_name");
				String source = rs.getString("source");
				String destination = rs.getString("destination");
				Date date= rs.getDate("date");
				train.add(new TrainEntity(train_no, train_name, source, destination, date));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return train;
	}

	
	private void printSQLException(SQLException ex) {
		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}
	}
}
