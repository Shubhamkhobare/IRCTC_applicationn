package com.application;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import jakarta.servlet.annotation.*;
import com.application.TrainEntity;
import com.application.traindaoo;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/AdminDashboard.jsp")
public class trainservlett extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private traindaoo trainDAO;
	
	public void init() {
		trainDAO = new traindaoo();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			default:
				listUser(request, response);
				break;
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}

	private void listUser(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<TrainEntity> listUser = trainDAO.selectAllUsers();
		request.setAttribute("listUser", listUser);
		RequestDispatcher dispatcher = request.getRequestDispatcher("AdminnDashboard.jsp");
		dispatcher.forward(request, response);
	}

}
