package com.application;
import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TrainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
	        throws ServletException, IOException {
	    try {
	        
	        TrainDAO trainDAO = new TrainDAO();
	        List<TrainEntity> trainList = trainDAO.getAllTrains();
	        
	        
	        if (trainList != null) {
	            
	            request.setAttribute("trainList", trainList);
	            
	          
	            RequestDispatcher dispatcher = request.getRequestDispatcher("AdminDashboard.jsp");
	    		dispatcher.forward(request, response);
	        } else {
	           
	            response.getWriter().write("No train data available.");
	        }
	    } catch (IOException | ServletException e) {
	       
	        e.printStackTrace();
	        response.getWriter().write("An error occurred while processing the request.");
	    }
	}
}