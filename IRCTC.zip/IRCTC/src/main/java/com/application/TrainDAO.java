package com.application;
import com.application.TrainEntity;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TrainDAO {
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/irctc?useSSL=false";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "1947Srksrk";

    public List<TrainEntity> getAllTrains() {
        List<TrainEntity> trainList = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT * FROM Trainn")) {

            while (resultSet.next()) {
                int trainNumber = resultSet.getInt("train_num");
                String trainName = resultSet.getString("train_name");
                String source = resultSet.getString("source");
                String destination = resultSet.getString("destination");
                Date date = resultSet.getDate("date");

                TrainEntity train = new TrainEntity(trainNumber, trainName, source, destination, date);
                trainList.add(train);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return trainList;
    }
}